# Pico code to gather temperature, humidity, light, and distance data
