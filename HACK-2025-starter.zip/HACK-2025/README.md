# HACK-2025

Spy-themed wearable device project using Raspberry Pi Pico and ESP32-CAM.
