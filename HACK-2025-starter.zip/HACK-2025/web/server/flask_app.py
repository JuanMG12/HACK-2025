# Flask server to communicate with ESP32-CAM and website
