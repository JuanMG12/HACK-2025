// JavaScript to update data and control camera
