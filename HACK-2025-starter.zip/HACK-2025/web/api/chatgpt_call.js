// Call ChatGPT API to decipher unknowns
