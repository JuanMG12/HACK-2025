# Data Communication Format

Define how data moves between devices.
