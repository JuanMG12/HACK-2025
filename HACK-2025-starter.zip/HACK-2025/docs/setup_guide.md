# Setup Guide

How to deploy the prototype and website.
